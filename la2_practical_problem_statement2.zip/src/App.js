import React ,{Component} from 'react';
import {BrowserRouter,Switch,Route,Redirect} from 'react-router-dom';
import './App.css';

import Form from './components/form.js'


class App extends Component{

  constructor(props){
    super(props);

    this.state = {
      
      
        name:null,
        branch:null,
        prn:null,
        clg:null,
        info:null
     
      
  };
  this.nameHandler=this.nameHandler.bind(this);
  this.branchHandler=this.branchHandler.bind(this);
  this.prnHandler=this.prnHandler.bind(this);
  this.clgHandler=this.clgHandler.bind(this);
  this.submit=this.submit.bind(this);


};

nameHandler(event){
 
  this.setState({
    name:event.target.value
  });
  console.log(this.state.name);

}
branchHandler(event){
 
  this.setState({
    branch:event.target.value
  });

}
prnHandler(event){
 
  this.setState({
    prn:event.target.value
  });

}
clgHandler(event){
 
  this.setState({
    clg:event.target.value
  });

}
submit(){

  

  /*this.setState({
    data:{
      name:this.state.name,
      branch:this.state.branch,
      prn:this.state.prn,
      clg:this.state.clg

    }
  })

  console.log(this.state.data)*/
  window.location.href="/display"




}

render(){

  return (


        <div>

          <div>  
             <br></br> <br></br>
            <div id="header">
                Student Application Form (Input Section)
            </div>

            <br></br>
            <br></br>
            <br></br>

             <div id="form1">

             <form>
                <label> Name :</label> <br></br>
                <input type="text" onChange={this.nameHandler} ></input><br></br><br></br>
                <label> Branch :</label> <br></br>
                <input type="text"  onChange={this.branchHandler} ></input> <br></br><br></br>
                <label> PRN :</label> <br></br>
                <input type="text" onChange={this.prnHandler} ></input> <br></br><br></br>
                <label> College name :</label> <br></br>
                <input type="text"  onChange={this.clgHandler}></input>
            </form>
            <br></br><br></br>
           
            </div>
          

            <div>
             <br></br><br></br>
              Display data Section 
            </div > 
           <div id="display">
            <label> Name :</label> <br></br>
                <input type="text" value={this.state.name}  ></input><br></br><br></br>
                <label> Branch :</label> <br></br>
                <input type="text"  value={this.state.branch} ></input> <br></br><br></br>
                <label> PRN :</label> <br></br>
                <input type="text" value={this.state.prn} ></input> <br></br><br></br>
                <label> College name :</label> <br></br>
                <input type="text" value={this.state.clg} ></input>
           

             </div>

             <br></br>
             <br></br>
             <br></br>
           
           


            


            

            

        </div> 
            <BrowserRouter>
                
                <Switch>
                      <Route exact path="/display" component={()=><Form name={this.state.name} />} />
  
                </Switch>
  
                </BrowserRouter>
        </div>
  );

}
  
}

export default App;

