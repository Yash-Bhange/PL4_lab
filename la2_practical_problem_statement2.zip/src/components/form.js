import React ,{Component} from 'react';
import {BrowserRouter,Switch,Route,Redirect} from 'react-router-dom';



class Form extends Component{

  constructor(props){
    super(props);

   console.log(this.props.name)
   console.log(this.props.branch)


};


render(){

  return (
      <div> 
          
      </div>
        
  );

}
  
}

export default Form;

